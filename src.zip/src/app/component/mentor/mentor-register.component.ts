import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { MentorService } from 'src/app/services/mentor-service';


@Component({
    selector: 'mentor-register',
    templateUrl: './mentor-register.component.html'
})
export class MentorRegisterComponent implements OnInit{
    @ViewChild('f', {  }) signUpForm: NgForm;
    mentorSignUpStatus:boolean = false;

    mentor = {
        fullName : '',
        timing : '',
        technologies : '',
        facility : '',
        email : '',
        linkedUrl : '',
        qualification : '',
        experience : '',
        password : '',
       
      };

      constructor(private router : Router , private mentorService : MentorService) {

    }

      onSubmit() {
       this.mentor. fullName =  this.signUpForm.value.name;
       this.mentor. timing =  this.signUpForm.value.timing;
       this.mentor. technologies =  this.signUpForm.value.technologies;
       this.mentor. facility = this.signUpForm.value.facility;
       this.mentor. email =  this.signUpForm.value.email;
       this.mentor. linkedUrl =  this.signUpForm.value.linkedUrl;
       this.mentor. qualification =  this.signUpForm.value.qualification;
       this.mentor. experience =  this.signUpForm.value. experience;
       this.mentor. password =  this.signUpForm.value.password;

       this.mentorSignUpStatus = true;
       this.mentorService.mentorRegister(this.signUpForm.value).subscribe();
       if(this.mentorSignUpStatus = true ) {
        this.router.navigate(['/mentor-login']);
       }
      
    
     
     
      }
    ngOnInit(): void {
      
    }
  
}