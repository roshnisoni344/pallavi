import { Component, OnInit } from '@angular/core';
import { TrainingService } from 'src/app/services/training-service';


@Component({
    selector: 'mentor-completed-training',
    templateUrl: './mcompleted-training.component.html'
})
export class McompletedTrainingComponent implements OnInit{
  
    public completedTrainingList;
mentorId : number;
mentorId1 : number = 11;
    constructor (private trainingService : TrainingService){

    }
    ngOnInit(): void {
      this.getMentorCompletedTrainingList(this.mentorId1);
    }
  
    getMentorCompletedTrainingList(mentorId : number) {
        this.trainingService.getMentorCompletedTrainingList(mentorId).subscribe(
        data => { this.completedTrainingList = data},
        err =>console.log(this.completedTrainingList),
        
         );
        
            
            }
  
}