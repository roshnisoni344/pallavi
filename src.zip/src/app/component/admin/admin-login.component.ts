import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoginStatusService } from '../../login-status-service';
import { AppComponent } from '../../app.component';
import { Router } from '@angular/router';


@Component({
    selector: 'admin-login',
    templateUrl: './admin-login.component.html'
})
export class AdminLoginComponent implements OnInit{
  @ViewChild('f', {  }) loginForm: NgForm;
  adminLoginStatus:boolean = false;
 
    
    admin = {
        email: '',
        password:''
      };

    
    constructor(private router: Router , private loginStatusService : LoginStatusService , public callToApp : AppComponent) {

    }

 
setLoginStatus()  {
 
this.loginStatusService. setAdminLoginStatus(this.adminLoginStatus);
}


    onSubmit() {
       
       this.adminLoginStatus = true;

        this.admin.email = this.loginForm.value.email;
       
        this.admin.email = this.loginForm.value.password;
            
        this.setLoginStatus();

        this.callToApp.fromLogin();

        if(this. adminLoginStatus = true ) {
          this.router.navigate(['/admin-menu']);
         }
      
      }

    ngOnInit(): void {
      
    }
  
}