import { ICommandName } from 'selenium-webdriver';

export interface ITech {
    technologyName : string;
    duration: number;
    timing: string;
    fees: number;
    trainerName: string;
    Rating: String;
    
}